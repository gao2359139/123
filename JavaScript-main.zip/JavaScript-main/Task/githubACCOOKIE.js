//独立COOKIE文件     ck在``里面填写，多js换行，不填也要换行
let githubACnameVal = ``
let githubACurlVal = ``
let githubACheaderVal = ``
let githubACbodyVal = ``

let HHAVal = ``
let HHBVal = ``
let HHCVal = ``
let HHDVal = ``
let HHEVal = ``
let HHFVal = ``
let HHGVal = ``
let HHHVal = ``
let HHIVal = ``
let HHJVal = ``
let HHKVal = ``
let HHLVal = ``

let MMAVal = ``
let MMBVal = ``
let MMCVal = ``
let MMDVal = ``
let MMEVal = ``
let MMFVal = ``
let MMGVal = ``
let MMHVal = ``
let MMIVal = ``
let MMJVal = ``
let MMKVal = ``
let MMLVal = ``




let githubACcookie = {
    githubACnameVal: githubACnameVal,
    githubACurlVal: githubACurlVal,
    githubACheaderVal: githubACheaderVal,
    githubACbodyVal: githubACbodyVal,

    HHAVal: HHAVal,
    HHBVal: HHBVal,
    HHCVal: HHCVal,
    HHDVal: HHDVal,
    HHEVal: HHEVal,
    HHFVal: HHFVal,
    HHGVal: HHGVal,
    HHHVal: HHHVal,
    HHIVal: HHIVal,
    HHJVal: HHJVal,
    HHKVal: HHKVal,
    HHLVal: HHLVal,
    MMAVal: MMAVal,
    MMBVal: MMBVal,
    MMCVal: MMCVal,
    MMDVal: MMDVal,
    MMEVal: MMEVal,
    MMFVal: MMFVal,
    MMGVal: MMGVal,
    MMHVal: MMHVal,
    MMIVal: MMIVal,
    MMJVal: MMJVal,
    MMKVal: MMKVal,
    MMLVal: MMLVal,


}

module.exports = githubACcookie
