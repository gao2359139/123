//独立COOKIE文件     ck在``里面填写，多账号换行
let duokandianbodyVal = ``
let duokandianvideobodyVal = ``



let duokandiancookie = {

    duokandianbodyVal: duokandianbodyVal,
    duokandianvideobodyVal: duokandianvideobodyVal,
}

module.exports = duokandiancookie
